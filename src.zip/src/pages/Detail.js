import React, {useEffect, useState} from 'react';
import {useParams} from "react-router-dom";

function Detail({near, keys}) {
    const [stone, setStone] = useState({});
    const {id} = useParams();

    useEffect(() => {
        console.log("Detail ID from URL:", id);
        console.log("Keys:", keys);
        console.log("Near:", near);

        for (let key of keys) {
            console.log("Current Key:", key);
            const items = near[key];
            if (items) {
                for (let item of items) {
                    console.log("Checking Item:", item);
                    if (item.id == id) {  // Use == to allow type coercion if necessary
                        setStone(item);
                        break; // Stop the loop once we find the item
                    }
                }
            }
        }
    }, [id, keys, near]); // Include dependencies to ensure effect reruns when they change
    // useEffect(() => {
    //
    //
    //         for(let key of keys){
    //             console.log(key);
    //             for(let item of near[key]){
    //                 console.log(item);
    //                 if(item[id] == id){
    //                     setStone(item);
    //                      console.log(stone);
    //          }
    //     }
    // }
    // }, [id]);
    return (
        <div>
            <p></p>
        </div>
    );
}

export default Detail;
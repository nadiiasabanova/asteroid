
import './App.css';
import {BrowserRouter, Route, Routes} from "react-router-dom";
import Home from "./pages/Home";
import Detail from "./pages/Detail";
import Cart from "./pages/Cart";
import Header from "./layout/Header";
import {useState} from "react";
import css from './App.module.css';

function App() {
  const [cart, setCart] = useState([]);
  const [near, setNear] = useState ({});
  const [keys, setKeys] = useState([]);

  return (
    <div className={css.container}>
      <BrowserRouter>
        <Header/>
        <Routes>
          <Route path='/' element={<Home cart={cart} setCart={setCart}  near={near} setNear={setNear} keys={keys} setKeys={setKeys} />}/>
          <Route path='/cart' element={<Cart cart={cart}/>}/>
          <Route path='/detail/:id' element={<Detail near={near}  keys={keys}/>}/>
        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;
